<?php
/**
 * @author Javi Mata http://www.javimata.com
 * @copyright Copyright (c) 2010 - 2018 Javi Mata
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/
//no direct accees
defined ('_JEXEC') or die ('restricted aceess');

JHtml::_('bootstrap.tooltip');

if ( count($items) > 0 ):
?>
	<div id="icons-wrap" class="clearfix">
	<?php foreach ($items as $item): ?>

		<div class="icon-wrapper">
		
			<div class="icon">
				<a href="<?php echo $item->link; ?>" class="hasTooltip" target="<?php echo $item->target; ?>" title="<?php echo $item->description; ?>">
					<i class='<?php echo $item->icon; ?>'></i><br />
					<?php echo $item->title; ?>
				</a>
			</div>

		</div>
	<?php endforeach; ?>
	</div>
	<div id="icons-wrap-by">
		Dashboard create by <a href="https://www.javimata.com" target="_blank">Javi Mata</a> <i class="fas fa-external-link-alt"></i>
	</div>
<?php
endif;